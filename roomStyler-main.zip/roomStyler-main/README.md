# roomStyler

An easy to use and simple website idea that allows the user to upload a room of his, and a list of furniture products will be suggested. 
Note that you need to sign up in order to upload your image file.
